<?php
    namespace App\Core;

    class Controller {
        private $dbc;
        private $data = [];
        
        final function __construct(DatabaseConnection &$dbc) {
            $this->dbc = $dbc;
        }

        final public function &getDatabaseConnection(): \App\Core\DatabaseConnection {
            return $this->dbc;
        }

        final protected function set(string $name, $value): bool {
            $result = false;
            # Dozvoli normalnu konvenciju: Beskonacan broj reci
            if(preg_match("/^(?:[a-zA-Z0-9\s]+)*$/", $name)) {
                $this->data[$name] = $value;
                $result = true;
            }
            return $result;
        }

        final public function getData(): array {
            return $this->data;
        }
    }