<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _global/index.html */
class __TwigTemplate_0edf31ec0a14b0400b27224860b4c6295a7b2876d25ce6142fcf9c469c2662ed extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'naslov' => [$this, 'block_naslov'],
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <title>Conference Halls - ";
        // line 4
        $this->displayBlock('naslov', $context, $blocks);
        echo "</title>
        <meta charset=\"utf8\">
        <link rel=\"stylesheet\" type=\"text/css\" href=\"/MB/assets/css/main.css?d=<?php echo time(); ?>\">
    </head>
    <body>
        <header class=\"site-header\">
            <div class=\"banners\">
                <a href=\"/MB/\" class=\"banner\">
                    <img src=\"/MB/assets/img/banner-1.jpg\" alt=\"Banner 1\">
                </a>
            </div>
            <div class=\"social\">
                <a href=\"#\"><img src=\"/MB/assets/img/social/linkedin.png\" alt=\"LinkedIn\">\"</a>
                <a href=\"#\"><img src=\"/MB/assets/img/social/facebook.png\" alt=\"Facebook\">\"</a>
                <a href=\"#\"><img src=\"/MB/assets/img/social/youtube.png\" alt=\"YouTube\">\"</a>
            </div>
            <div class=\"search\">
                <form method=\"post\" action=\"/search\">
                    <input type=\"text\" name=\"query\" placeholder=\"Date of Hall availability\">
                    <button type=\"submin\">Search by date</button>
                </form>
            </div>
            <nav id=\"main-menu\">
                <ul>
                    <li><a href=\"/MB/\">Home</a>
                    <li><a href=\"/MB/halls/\">Halls</a>
                    <li><a href=\"/MB/profile/\">Profile</a>
                    <li><a href=\"/MB/contact/\">Contact</a>
                    <li><a href=\"/MB/about/\">About Us</a>
                    <li><a href=\"/MB/log-out/\">Log Out</a>
                </ul>
            </nav>
        </header>
        <main>
            ";
        // line 38
        $this->displayBlock('main', $context, $blocks);
        // line 40
        echo "        </main>
        <footer class=\"site-footer\">
            &copy; 2019 Males & Boggiano, Univerzitet Singidunum
            <p>Belgrade current time (CEST): ";
        // line 43
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "d. m. Y. H:i", "Europe/Belgrade"), "html", null, true);
        echo "</p>
        </footer>
    </body>
</html>";
    }

    // line 4
    public function block_naslov($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Home";
    }

    // line 38
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 39
        echo "            ";
    }

    public function getTemplateName()
    {
        return "_global/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 39,  103 => 38,  96 => 4,  88 => 43,  83 => 40,  81 => 38,  44 => 4,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "_global/index.html", "C:\\xampp\\htdocs\\MB\\views\\_global\\index.html");
    }
}
