<?php
    namespace App\Models;
    use App\Core\DatabaseConnection;
    use \PDO;

    class HallModel {
        private $dbc;

        public function __construct(DatabaseConnection &$dbc) {
            $this->dbc = $dbc;
        }

        public function getById(int $hallid){
            $sql = "SELECT * FROM hall WHERE hall_id = ?;";
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute([$hallid]);
            $user = NULL;
            if($res){
                $user = $prep->fetch(PDO::FETCH_OBJ);
            }
            return $user;
        }

        public function getAll(): array {
            $sql = "SELECT * FROM hall;";
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute();
            $halls = [];
            if($res){
                $halls = $prep->fetchAll(PDO::FETCH_OBJ);
            }
            return $halls;
        }

        public function getByName(string $name){
            $sql = "SELECT * FROM hall WHERE name = ?;";
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute([$name]);
            $hall = NULL;
            if($res){
                $hall = $prep->fetch(PDO::FETCH_OBJ);
            }
            return $hall;
        }


    }