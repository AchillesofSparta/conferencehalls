<?php
    namespace App\Models;
    use App\Core\DatabaseConnection;
    use \PDO;

    class FeatureModel {
        private $dbc;

        public function __construct(DatabaseConnection &$dbc) {
            $this->dbc = $dbc;
        }

        public function getById(int $featureid){
            $sql = "SELECT * FROM feature WHERE feature_id = ?;";
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute([$featureid]);
            $feature = NULL;
            if($res){
                $feature = $prep->fetch(PDO::FETCH_OBJ);
            }
            return $feature;
        }

        public function getByName(string $name){
            $sql = "SELECT * FROM feature WHERE name = ?;";
            $prep = $this->dbc->getConnection()->prepare($sql);
            $res = $prep->execute([$name]);
            $feature = NULL;
            if($res){
                $feature = $prep->fetch(PDO::FETCH_OBJ);
            }
            return $feature;
        }

        public function getAllByHallId(int $hallId): array {
            $sqlFeatureId = "SELECT * FROM hall_feature where hall_id = ?;";
            $prep = $this->dbc->getConnection()->prepare($sqlFeatureId);
            $res = $prep->execute([$hallId]);
            $features = [];
            if($res){
                $features = $prep->fetchAll(PDO::FETCH_OBJ);
            }
            
            return $features;
        }

        
        public function getFeatureNameById(int $id){
            $sql = "SELECT * FROM features WHERE feature_id = ?;";
            $prep2 = $this->dbc->getConnection()->prepare($sql);
            $res2 = $prep2->execute([$id]);
            $featureName = NULL;
            if($res2){
                $featureName = $prep2->fetch(PDO::FETCH_OBJ);
            }

            return $featureName;
        }
        

    }