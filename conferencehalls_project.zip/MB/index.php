<?php
    require_once('DatabaseConfiguration.php');
    require_once('DatabaseConnection.php');
    require_once('models/UserModel.php');

    $databaseConfiguration = new DatabaseConfiguration("localhost","root","","conferencehalls");
    $databaseConnection = new DatabaseConnection($databaseConfiguration);

    $userModel = new UserModel($databaseConnection);
    $users = $userModel->getAll();
    $users2 = $userModel->getByUsername("bogdan.nikic.14@gmail.com");
    $users3 = $userModel->getById("2");

    $message = "Korisnik ne postoji!";
    if($users2 !== NULL){
        $message = print_r($users2);
    }
    
    #print_r($users2);
    #print_r($users3);




    /*
    $prep = $databaseConnection->getConnection()->prepare("SELECT * FROM administrator;");
    $res = $prep->execute();
    $user = [];
    if($res){
        $user = $prep->fetchAll(PDO::FETCH_OBJ);
    }

    # Povezivanje sa bazom
    $source = "mysql:host=localhost;dbname=conferencehalls;charset=utf8";
    $user = "root";
    $pwd = "";
    $db = new PDO($source, $user, $pwd);

    # Priprema upita    
    $hallId = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

    $prep = $db->prepare("SELECT * FROM hall WHERE hall_id = ?;");
    $res = $prep->execute([ $hallId ]);

    # Provera vracenih informacija
    $halls = NULL;
    if($res){
        $halls = $prep->fetch(PDO::FETCH_OBJ);
    }

    # Ispis
    print_r($halls);
    */