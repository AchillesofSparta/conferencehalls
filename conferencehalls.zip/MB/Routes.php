<?php
    return [
        App\Core\Route::get("|^hall/([0-9]+)/?$|", "Hall", "show"),
        App\Core\Route::get("|^hall/([0-9]+)/delete/?$|", "Hall", "delete"),

        App\Core\Route::any('|^.*$|', 'Main', 'home')
    ];