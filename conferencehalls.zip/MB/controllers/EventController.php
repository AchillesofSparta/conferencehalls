<?php
    namespace App\Controllers;

    use App\Core\DatabaseConnection;
    use App\Models\UserModel;
    use App\Models\HallModel;

    class EventController extends \App\Core\Controller {
        
        public function show($id) {
            $eventModel = new EventModel($this->getDatabaseConnection());
            $event = $eventModel->getById($id);

            if(!$event){
                header("Location: /MB/");
                exit;
            }   

            $this->set("event", $event); 
        }

    }