<?php
    namespace App\Controllers;

    use App\Core\DatabaseConnection;
    use App\Models\UserModel;
    use App\Models\HallModel;

    class MainController extends \App\Core\Controller {
        
        public function home() {
            $hallModel = new HallModel($this->getDatabaseConnection());
            $halls = $hallModel->getAll();

            if(!$halls){
                header("Location: /MB/");
                exit;
            }

            $this->set("halls", $halls);        
        }

    }