<?php
    require_once 'vendor/autoload.php';
    require_once 'Configuration.php';

    use App\Core\DatabaseConfiguration;
    use App\Core\DatabaseConnection;
    use App\Core\Router;
    use App\Core\Route;
    use App\Models\UserModel;
    use App\Models\HallModel;
    use App\Controllers\MainController;

    $databaseConfiguration = new DatabaseConfiguration(
        Configuration::DATABASE_HOST,
        Configuration::DATABASE_USER,
        Configuration::DATABASE_PASS,
        Configuration::DATABASE_NAME
    );

    $databaseConnection = new DatabaseConnection($databaseConfiguration);


    $url = strval(filter_input(INPUT_GET, "URL"));
    $httpMethod =filter_input(INPUT_SERVER, "REQUEST_METHOD");

    $router = new Router();
    $routes = require_once "Routes.php";

    foreach ($routes as $route){
        $router->add($route);
    }

    $route = $router->find($httpMethod, $url);
    $arguments = $route->extractArguments($url);
    
    $fullControllerName = "\\App\\Controllers\\" . $route->getControllerName() . "Controller";
    $controller = new $fullControllerName($databaseConnection);
    call_user_func_array([$controller, $route->getMethodName()], $arguments);
    $data = $controller->getData();

    // Template View Rendering
    // Set AUTO_RELOAD to FALSE or REMOVE upon project completion
    $loader = new Twig_Loader_Filesystem("./views");
    $twig = new Twig_Environment($loader, [
        "cache" => "./twig-cache",
        "auto_reload" => true
    ]);
    echo $twig->render($route->getControllerName() . "/" . $route->getMethodName() . ".html", $data);
    

    # EOF
    //////////////////////////////////////////////////////////////////////
    //OLD TEST CODE
    /* CUSTOM VIEW GENERATION
    foreach($data as $name => $value) {
        $$name = $value;
    }
    # Dynamic views
    require_once "views/" . $route->getControllerName() . "/" . $route->getMethodName() . ".php";
    */
    /*
    $userModel = new UserModel($databaseConnection);
    $users = $userModel->getAll();
    $users2 = $userModel->getByUsername("bogdan.nikic.14@gmail.com");
    $users3 = $userModel->getById("2");

    $message = "Korisnik ne postoji!";
    if($users2 !== NULL){
        $message = print_r($users2);
    }
    
    # echo $message;

    $hallModel = new App\Models\HallModel($databaseConnection);
    $halls = $hallModel->getAll();
    print_r($halls);


    #print_r($users2);
    #print_r($users3);
    */

    /*
    $prep = $databaseConnection->getConnection()->prepare("SELECT * FROM administrator;");
    $res = $prep->execute();
    $user = [];
    if($res){
        $user = $prep->fetchAll(PDO::FETCH_OBJ);
    }

    # Povezivanje sa bazom
    $source = "mysql:host=localhost;dbname=conferencehalls;charset=utf8";
    $user = "root";
    $pwd = "";
    $db = new PDO($source, $user, $pwd);

    # Priprema upita    
    $hallId = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

    $prep = $db->prepare("SELECT * FROM hall WHERE hall_id = ?;");
    $res = $prep->execute([ $hallId ]);

    # Provera vracenih informacija
    $halls = NULL;
    if($res){
        $halls = $prep->fetch(PDO::FETCH_OBJ);
    }

    # Ispis
    print_r($halls);
    */