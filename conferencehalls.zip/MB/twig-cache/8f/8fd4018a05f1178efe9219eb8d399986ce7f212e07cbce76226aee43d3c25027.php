<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Hall/show.html */
class __TwigTemplate_fabcef27c501369660b74df4bbbda2b67a923e66ed505ea78c10dd23571a5229 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'naslov' => [$this, 'block_naslov'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_global/index.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("_global/index.html", "Hall/show.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <h1>";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["hall"] ?? null), "name", [], "any", false, false, false, 4));
        echo "</h1>
    <p>All features found bellow are present:</p>
    <ul>
        ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["hallFeatureNames"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["hallFeatureName"]) {
            // line 8
            echo "            <li>
                ";
            // line 9
            if ((twig_get_attribute($this->env, $this->source, $context["hallFeatureName"], "name", [], "any", false, false, false, 9) == "Seats")) {
                echo "                
                    <p>";
                // line 10
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hallFeatureName"], "name", [], "any", false, false, false, 10), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_first($this->env, ($context["hallFeatures"] ?? null)), "value", [], "any", false, false, false, 10), "html", null, true);
                echo "</p>
                ";
            } else {
                // line 12
                echo "                    <p>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hallFeatureName"], "name", [], "any", false, false, false, 12), "html", null, true);
                echo "</p>
                ";
            }
            // line 14
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['hallFeatureName'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo " 
    </ul>
    ";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["hall"] ?? null), "description", [], "any", false, false, false, 16));
        echo "
    
";
    }

    // line 20
    public function block_naslov($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["hall"] ?? null), "name", [], "any", false, false, false, 21));
        echo "
";
    }

    public function getTemplateName()
    {
        return "Hall/show.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 21,  98 => 20,  91 => 16,  82 => 14,  76 => 12,  69 => 10,  65 => 9,  62 => 8,  58 => 7,  51 => 4,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "Hall/show.html", "C:\\xampp\\htdocs\\MB\\views\\Hall\\show.html");
    }
}
