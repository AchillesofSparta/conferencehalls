<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Main/home.php */
class __TwigTemplate_77770a25fb41224dffc5c386a231c664a77cdb240684f42c42f48769716c5dad extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<nav>
    <ul>
        <?php foreach (\$halls as \$hall): ?>
        <li>
            <a href=\"/MB/hall/<?php echo \$hall->hall_id; ?>\">
                <?php echo htmlspecialchars(\$hall->name); ?>
            </a>
        <?php endforeach; ?>
    </ul>
</nav>";
    }

    public function getTemplateName()
    {
        return "Main/home.php";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "Main/home.php", "C:\\xampp\\htdocs\\MB\\views\\Main\\home.php");
    }
}
